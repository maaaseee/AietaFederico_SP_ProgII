package spbiblioteca;

public class ItemAlreadyInListException extends RuntimeException{
    public static final String MESSAGE = "Esta lista ya tiene el elemento que se desea agregar.";
    
    public ItemAlreadyInListException() {
        super(MESSAGE);
    }
}

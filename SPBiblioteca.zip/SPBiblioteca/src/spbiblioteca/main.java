package spbiblioteca;

import java.io.IOException;

public class main {

    public static void main(String[] args) {
        try {
            // Crear un inventario de libros
            Inventario<Libro> inventarioLibros = new Inventario<>();
            inventarioLibros.agregar(new Libro(1, "1984", "George Orwell",Categoria.ENTRETENIMIENTO));
            inventarioLibros.agregar(new Libro(2, "El se�or de los anillos", "J.R.R.Tolkien", Categoria.LITERATURA));
            inventarioLibros.agregar(new Libro(3, "Cien a�os de soledad", "Gabriel Garc�a M�rquez", Categoria.LITERATURA));
            inventarioLibros.agregar(new Libro(4, "El origen de las especies", "Charles Darwin", Categoria.CIENCIA));
            inventarioLibros.agregar(new Libro(5, "La guerra de los mundos", "H.G.Wells", Categoria.ENTRETENIMIENTO));
            
            // Mostrar todos los libros en el inventario
            System.out.println("Inventario de libros:");
            inventarioLibros.paraCadaElemento(l -> System.out.println(l));
            
            // Filtrar libros por categor�a LITERATURA
            System.out.println("\nLibros de la categor�a LITERATURA:");
            inventarioLibros.filtrar(l -> l.getCategoria().equals(Categoria.LITERATURA)).forEach(libro -> System.out.println(libro));
            
            // Filtrar libros cuyo t�tulo contiene "1984"
            System.out.println("\nLibros cuyo t�tulo contiene '1984':");
            inventarioLibros.filtrar(l -> l.getTitulo().contains("1984")).forEach(libro -> System.out.println(libro));
           
            // Ordenar libros de manera natural (por id)
            System.out.println("\nLibros ordenados de manera natural (por id):");
            inventarioLibros.ordenar();
            inventarioLibros.paraCadaElemento(libro -> System.out.println(libro));
            
            // Ordenar libros por t�tulo utilizando un Comparator
            System.out.println("\nLibros ordenados por t�tulo:");
            inventarioLibros.ordenar((l1, l2) -> {
                return l1.getTitulo().compareTo(l2.getTitulo());
            });
            inventarioLibros.paraCadaElemento(libro -> System.out.println(libro));
            
            // Guardar el inventario en un archivo binario
            inventarioLibros.guardarArchivoBinario("src/data/libros.dat");
            
            // Cargar el inventario desde el archivo binario
            Inventario<Libro> inventarioCargado = new Inventario<>();
            inventarioCargado.cargarArchivoBinario("src/data/libros.dat");
            System.out.println("\nLibros cargados desde archivo binario:");
            inventarioCargado.paraCadaElemento(libro -> System.out.println(libro));
            
            // Guardar el inventario en un archivo CSV
            inventarioLibros.guardarArchivoCSV("src/data/libros.csv");
            
            // Cargar el inventario desde el archivo CSV
            inventarioCargado.cargarArchivoCSV("src/data/libros.csv", Libro::fromCSV);
            System.out.println("\nLibros cargados desde archivo CSV:");
            inventarioCargado.paraCadaElemento(libro -> System.out.println(libro));
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
        
    }
}

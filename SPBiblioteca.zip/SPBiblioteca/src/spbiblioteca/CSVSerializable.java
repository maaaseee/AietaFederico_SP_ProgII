package spbiblioteca;

public interface CSVSerializable {
    String toCSV();
}

package spbiblioteca;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends CSVSerializable> implements Iterable<T> {
    private List<T> inventario = new LinkedList<>();
    
    public void agregar(T obj) {
        if (obj == null) {
            throw new NullPointerException("Este objeto ingresado, es un nulo.");
        }
        if (inventario.contains(obj)) {
            throw new ItemAlreadyInListException();
        }
        inventario.add(obj);
    }
    
    public T obtener(int indice) {
        validateIndex(indice);
        return inventario.get(indice);
    }

    
    public void eliminar(int indice) {
        validateIndex(indice);
        inventario.remove(indice);
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for (T item : inventario) {
            if (criterio.test(item)) {
                toReturn.add(item);
            }
        }
        
        return toReturn;
    }
    
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : inventario) {
            accion.accept(item);
        }
    }
    
    public int tamanio() {
        return inventario.size();
    }
    
    private void validateIndex(int index) {
        if (index < 0 || index >= tamanio()) {
            throw new IndexOutOfBoundsException("El item que desea buscar no se encuentra en la lista.");
        }
    }
    
    public void ordenar() {
        if (!(inventario.isEmpty()) && inventario.get(0) instanceof Comparable) {
            inventario.sort(null);
        }
    }
    
    
    public void ordenar(Comparator<? super T> comparador) {
        if (!(inventario.isEmpty()) && inventario.get(0) instanceof Comparable) {
            inventario.sort(comparador);
        }
    }
    
    @Override
    public Iterator<T> iterator() {
        return inventario.iterator();
    }
    
    public void guardarArchivoBinario(String path) throws IOException {
        crearArchivo(path);
        
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(inventario);
            System.out.println("Elementos guardados correctamente en formato binario.");
        }
    }
    
    public void cargarArchivoBinario(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            inventario = (List<T>) input.readObject();
        } 
    }
    
    public void guardarArchivoCSV(String path) throws IOException {
        crearArchivo(path);
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("ID,Titulo,Autor,Categoria");
            for (T e : inventario) {
                bw.newLine();
                bw.write(e.toCSV());
            }
        }
    }
    
    public void cargarArchivoCSV(String path, Function<String[], T> parser) throws IOException {
        List<T> toReturn = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 4) {
                    toReturn.add(parser.apply(datos));
                }
            }
        }
        inventario = toReturn;
    }
    
    private boolean crearArchivo(String path) throws IOException {
        File archivo = new File(path);
        if(!archivo.exists()) {
            return archivo.createNewFile();
        }

        return true;
    }
}

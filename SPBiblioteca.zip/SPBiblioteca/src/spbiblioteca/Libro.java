package spbiblioteca;

import java.io.Serializable;

public class Libro implements Serializable, Comparable<Libro>, CSVSerializable {
    private final int ID;
    private String titulo;
    private String autor;
    private Categoria categoria;

    public Libro(int ID, String titulo, String autor, Categoria categoria) {
        this.ID = ID;
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
    }
    
    public Categoria getCategoria() {
        return categoria;
    }
    
    public String getTitulo() {
        return titulo;
    }

    @Override
    public int compareTo(Libro o) {
        return Integer.compare(ID, o.ID);
    }  

    @Override
    public String toCSV() {
        return ID + "," + titulo + "," + autor + "," + categoria;
    }

    @Override
    public String toString() {
        return "Libro{" + "ID=" + ID + ", titulo=" + titulo + ", autor=" + autor + ", categoria=" + categoria + '}';
    }
    
    public static Libro fromCSV(String[] datos) {
        int id = Integer.parseInt(datos[0]);
        String titulo = datos[1];
        String autor = datos[2];
        Categoria categoria = Categoria.valueOf(datos[3].toUpperCase());
        
        return new Libro(id, titulo, autor, categoria);
    }
}
